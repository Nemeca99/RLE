# Using Physics Toolbox Sensor Suite with RLE

Since you already have the paid version of Physics Toolbox Sensor Suite, you can skip building the Android app and use this workflow instead.

## Workflow

### 1. Collect Data with Physics Toolbox

1. Open Physics Toolbox Sensor Suite on your phone
2. Enable sensors:
   - CPU Usage
   - CPU Frequency
   - Battery Temperature
   - Battery Voltage
   - Battery Current
3. Start recording
4. Run your workload/test
5. Stop recording
6. Export as CSV

### 2. Transfer to Desktop

```bash
# Via USB/ADB
adb pull /sdcard/Download/physics_toolbox_export.csv .

# Or via email/Drive/Dropbox
# Download CSV to desktop
```

### 3. Convert to RLE Format

```bash
python lab/analysis/physics_toolbox_rle.py physics_toolbox_export.csv phone_rle.csv
```

This script:
- Detects column names automatically
- Computes RLE from sensor data
- Outputs CSV compatible with desktop pipeline

### 4. Analyze

```bash
# Single-session analysis
python lab/analysis/rle_comprehensive_timeline.py phone_rle.csv

# Cross-device comparison
python lab/analysis/cross_domain_rle.py \
    sessions/recent/rle_20251027_18_cpu.csv \
    sessions/recent/rle_20251027_18_gpu.csv \
    phone_rle.csv
```

## Column Mapping

The converter automatically detects Physics Toolbox column names. It looks for:

| Physics Toolbox | RLE Mapping |
|----------------|-------------|
| CPU Usage | → `util_pct` |
| CPU Frequency | → `cpu_freq_ghz` |
| Battery Temp | → `temp_c` |
| Battery Voltage | → Power calculation |
| Battery Current | → Power calculation |

If exact names don't match, the script uses fuzzy matching (contains "cpu", "battery", "temp", etc.).

## Advantages vs Custom Android App

**Physics Toolbox approach**:
- ✅ Already on your phone (no build needed)
- ✅ Professional sensor suite
- ✅ Potentially more sensor access (if your device supports it)
- ⚠️ Manual export (not automatic)
- ⚠️ No real-time RLE dashboard

**Custom Android app**:
- ✅ Real-time RLE computation
- ✅ Live dashboard
- ✅ Automatic hourly rotation
- ✅ Built for RLE workflow
- ⚠️ Need to build APK

## Use Both?

You can collect data with **either** method - they both produce the same RLE-compatible CSV format. Mix and match as needed:

```bash
# Desktop CPU
python lab/analysis/cross_domain_rle.py \
    sessions/recent/rle_20251027_18_cpu.csv \
    sessions/recent/rle_20251027_18_gpu.csv

# Mobile via Physics Toolbox
python lab/analysis/cross_domain_rle.py \
    sessions/recent/rle_20251027_18_cpu.csv \
    sessions/recent/rle_20251027_18_gpu.csv \
    phone_physics_toolbox_rle.csv

# Result: σ < 0.20 (universal RLE law confirmed)
```

Choose the tool that makes sense for your workflow.

