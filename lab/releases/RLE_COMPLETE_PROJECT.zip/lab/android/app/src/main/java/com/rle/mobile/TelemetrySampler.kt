package com.rle.mobile

import android.content.Context
import android.os.*
import android.os.BatteryManager
import java.io.BufferedReader
import java.io.FileReader
import java.util.*

/**
 * Telemetry Sampler for Android
 * 
 * Reads CPU utilization, frequency, battery data, and thermal status
 * without requiring root access.
 */
class TelemetrySampler(private val context: Context) {
    
    data class Sample(
        val timestamp: Long,
        val cpuUtilPct: Double,
        val cpuFreqHz: Double,  // Hz
        val batteryTempC: Double?,
        val batteryVoltageV: Double?,
        val batteryCurrentA: Double?,  // Amps (negative if discharging)
        val batteryLevel: Int,  // 0-100
        val thermalStatus: Int,  // 0=NORMAL, 1=LIGHT, 2=MODERATE, 3=SEVERE, 4=CRITICAL
        val alerts: List<String>
    )
    
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val cpuFreqPath = "/sys/devices/system/cpu/cpu"
    
    /**
     * Sample all telemetry at once
     */
    fun sample(): Sample {
        val timestamp = System.currentTimeMillis()
        val alerts = mutableListOf<String>()
        
        // CPU utilization
        val cpuUtil = readCPUUtilization()
        
        // CPU frequency (use big core as proxy)
        val cpuFreq = readCPUFrequency()
        
        // Battery data
        val batteryData = readBatteryData()
        
        // Thermal status
        val thermalStatus = readThermalStatus()
        
        // Safety alerts
        if (batteryData.tempC != null && batteryData.tempC > 50.0) {
            alerts.add("BATTERY_TEMP_HIGH")
        }
        if (thermalStatus >= 3) {  // SEVERE or CRITICAL
            alerts.add("THERMAL_THROTTLE")
        }
        
        return Sample(
            timestamp = timestamp,
            cpuUtilPct = cpuUtil,
            cpuFreqHz = cpuFreq,
            batteryTempC = batteryData.tempC,
            batteryVoltageV = batteryData.voltageV,
            batteryCurrentA = batteryData.currentA,
            batteryLevel = batteryData.level,
            thermalStatus = thermalStatus,
            alerts = alerts
        )
    }
    
    /**
     * Read CPU utilization from /proc/stat
     */
    private fun readCPUUtilization(): Double {
        return try {
            val reader = BufferedReader(FileReader("/proc/stat"))
            val line = reader.readLine()
            reader.close()
            
            // Parse: cpu user nice system idle iowait irq softirq
            val parts = line.split("\\s+".toRegex())
            if (parts.size < 8) return 0.0
            
            val user = parts[1].toLong()
            val nice = parts[2].toLong()
            val system = parts[3].toLong()
            val idle = parts[4].toLong()
            val iowait = if (parts.size > 5) parts[5].toLongOrNull() ?: 0 else 0
            val irq = if (parts.size > 6) parts[6].toLongOrNull() ?: 0 else 0
            val softirq = if (parts.size > 7) parts[7].toLongOrNull() ?: 0 else 0
            
            val total = user + nice + system + idle + iowait + irq + softirq
            val active = user + nice + system + iowait + irq + softirq
            
            // Cache previous values for accurate diff
            // For now, return a simple estimate based on active time
            val utilization = (active.toDouble() / max(total, 1)) * 100.0
            utilization.coerceIn(0.0, 100.0)
            
        } catch (e: Exception) {
            0.0
        }
    }
    
    /**
     * Read CPU frequency from /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq
     * Returns the highest frequency across all cores (proxy for big core)
     */
    private fun readCPUFrequency(): Double {
        var maxFreq = 0.0
        
        // Try CPU0 through CPU7 (most phones have 8 cores)
        for (i in 0..7) {
            try {
                val path = "${cpuFreqPath}${i}/cpufreq/scaling_cur_freq"
                val reader = BufferedReader(FileReader(path))
                val freq = reader.readLine().toLongOrNull() ?: 0
                reader.close()
                if (freq > maxFreq) {
                    maxFreq = freq.toDouble()
                }
            } catch (e: Exception) {
                // Core doesn't exist or not readable
            }
        }
        
        // If no cores readable, fall back to nominal frequency
        if (maxFreq == 0.0) {
            maxFreq = 2.4e9  // Typical big core frequency (S24)
        }
        
        return maxFreq  // Return in Hz
    }
    
    /**
     * Read battery data via BatteryManager
     */
    private fun readBatteryData(): BatteryData {
        val tempC = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_TEMPERATURE)
                .takeIf { it != Integer.MIN_VALUE }?.div(10.0)  // Convert deciCelsius to Celsius
        
        val voltageMV = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_VOLTAGE_NOW)
        val voltageV = voltageMV.takeIf { it != Integer.MIN_VALUE }?.div(1000.0)
        
        val currentMA = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val currentA = currentMA.takeIf { it != Integer.MIN_VALUE }?.div(1000.0)
        
        val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
                .let { if (it != Integer.MIN_VALUE) it / 10 else 0 }
        
        return BatteryData(tempC, voltageV, currentA, level)
    }
    
    /**
     * Read thermal status via ThermalManager (API 31+)
     */
    private fun readThermalStatus(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val thermalManager = context.getSystemService(Context.THERMAL_SERVICE) as ThermalManager
                
                // Get thermal status from all thermal zones
                // 0 = NORMAL, 1 = LIGHT, 2 = MODERATE, 3 = SEVERE, 4 = CRITICAL, 5 = SHUTDOWN, 6 = EMERGENCY
                val threshold = when (thermalManager.currentThermalStatus) {
                    ThermalStatus.LEVEL_NONE, ThermalStatus.LEVEL_LIGHT -> 0
                    ThermalStatus.LEVEL_MODERATE -> 1
                    ThermalStatus.LEVEL_SEVERE -> 2
                    ThermalStatus.LEVEL_CRITICAL -> 3
                    ThermalStatus.LEVEL_EMERGENCY -> 4
                    else -> 0
                }
                threshold
            } catch (e: Exception) {
                0
            }
        } else {
            // API < 31: infer from battery temperature
            val temp = readBatteryData().tempC
            when {
                temp == null -> 0
                temp > 50 -> 2  // MODERATE
                temp > 45 -> 1  // LIGHT
                else -> 0       // NORMAL
            }
        }
    }
    
    /**
     * Estimate power draw from battery current and voltage
     * Returns watts (positive = discharging, negative = charging)
     */
    fun estimatePowerW(voltageV: Double?, currentA: Double?): Double? {
        if (voltageV == null || currentA == null) return null
        // Current is negative when discharging, positive when charging
        // We want absolute power draw
        return kotlin.math.abs(voltageV * currentA)
    }
    
    private data class BatteryData(
        val tempC: Double?,
        val voltageV: Double?,
        val currentA: Double?,
        val level: Int
    )
}

