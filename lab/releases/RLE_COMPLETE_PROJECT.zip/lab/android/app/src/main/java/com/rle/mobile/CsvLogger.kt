package com.rle.mobile

import android.content.Context
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

/**
 * CSV Logger - Compatible with desktop RLE pipeline
 * 
 * Writes session data in the same format as hardware_monitor.py
 * so you can analyze with rle_comprehensive_timeline.py
 */
class CsvLogger(private val context: Context) {
    
    private val sessionsDir = File(context.filesDir, "sessions")
    private var currentFile: File? = null
    private var writer: FileWriter? = null
    private var currentHourKey: String? = null
    
    init {
        sessionsDir.mkdirs()
    }
    
    /**
     * Get or create the current session file
     */
    private fun getCurrentFile(): FileWriter {
        val hourKey = SimpleDateFormat("yyyyMMdd_HH", Locale.US).format(Date())
        
        if (hourKey != currentHourKey) {
            // Rotate to new file
            writer?.close()
            
            val fileName = "rle_${hourKey}_mobile.csv"
            val file = File(sessionsDir, fileName)
            
            val newFile = !file.exists()
            
            currentFile = file
            writer = FileWriter(file, true)
            
            if (newFile) {
                writeHeader()
            }
            
            currentHourKey = hourKey
        }
        
        return writer!!
    }
    
    /**
     * Write CSV header (compatible with desktop format)
     */
    private fun writeHeader() {
        writer?.append("timestamp,device,rle_smoothed,rle_raw,rle_norm,E_th,E_pw,temp_c,vram_temp_c,")
        writer?.append("power_w,util_pct,a_load,t_sustain_s,fan_pct,rolling_peak,collapse,alerts,")
        writer?.append("cpu_freq_ghz,cycles_per_joule\n")
        writer?.flush()
    }
    
    /**
     * Write a sample to CSV
     */
    fun log(
        timestamp: String,
        rleResult: RLEEngine.RLEResult?,
        sampler: TelemetrySampler.Sample
    ) {
        val writer = getCurrentFile()
        
        // Format: ISO 8601 UTC timestamp
        val isoTime = timestamp
        
        val rleSmoothed = rleResult?.rleSmoothed ?: 0.0
        val rleRaw = rleResult?.rleRaw ?: 0.0
        val rleNorm = rleResult?.rleNorm ?: 0.0
        val eTh = rleResult?.eTh ?: 0.0
        val ePw = rleResult?.ePw ?: 0.0
        
        // Temperature (use battery temp as proxy for SoC temp)
        val tempC = sampler.batteryTempC?.toString() ?: ""
        
        // Power estimate
        val powerW = sampler.estimatePowerW()
        
        val utilPct = sampler.cpuUtilPct
        val aLoad = rleResult?.aLoad ?: 0.0
        val tSustain = rleResult?.tSustain ?: 0.0
        
        val rollingPeak = rleResult?.let { RLEEngine(0.0, 0.0).getRollingPeak() } ?: 0.0
        val collapse = if (rleResult?.isCollapsed() == true) 1 else 0
        val alerts = sampler.alerts.joinToString("|")
        
        // CPU frequency in GHz
        val cpuFreqGhz = (sampler.cpuFreqHz / 1e9).toString()
        
        // Cycles per joule
        val cyclesPerJoule = rleResult?.let {
            RLEEngine(0.0, 0.0).getCyclesPerJoule(sampler.cpuFreqHz, powerW)
        }?.toString() ?: ""
        
        // Write row
        writer.append("$isoTime,mobile,")
        writer.append("${rleSmoothed},${rleRaw},${rleNorm},")
        writer.append("${eTh},${ePw},")
        writer.append("${tempC},,")  // No VRAM temp on mobile
        writer.append("${powerW?.toString() ?: ""},")
        writer.append("${utilPct},${aLoad},${tSustain},")
        writer.append(",${rollingPeak},")  // No fan on mobile
        writer.append("${collapse},${alerts},")
        writer.append("${cpuFreqGhz},${cyclesPerJoule}\n")
        
        writer.flush()
    }
    
    /**
     * Export all session files to a shareable location
     */
    fun exportSessions(): List<File> {
        return sessionsDir.listFiles()?.toList() ?: emptyList()
    }
    
    /**
     * Clean up old session files (older than N days)
     */
    fun cleanupOldSessions(maxAgeDays: Int = 7) {
        val cutoff = System.currentTimeMillis() - (maxAgeDays * 24 * 60 * 60 * 1000)
        
        sessionsDir.listFiles()?.forEach { file ->
            if (file.lastModified() < cutoff) {
                file.delete()
            }
        }
    }
    
    /**
     * Close and cleanup
     */
    fun close() {
        writer?.close()
        writer = null
        currentFile = null
        currentHourKey = null
    }
}

/**
 * Extension to estimate power from battery telemetry
 */
fun TelemetrySampler.Sample.estimatePowerW(): Double? {
    if (batteryVoltageV == null || batteryCurrentA == null) return null
    return kotlin.math.abs(batteryVoltageV * batteryCurrentA)
}

