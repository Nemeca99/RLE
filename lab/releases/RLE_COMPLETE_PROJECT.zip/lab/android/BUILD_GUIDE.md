# Building RLE Mobile App

## Prerequisites

- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK API 34
- Kotlin 1.9+
- Gradle 8.0+

## Quick Start

```bash
# Clone repository (if not already done)
cd lab/android

# Open in Android Studio
studio .

# Or build from command line
./gradlew assembleDebug

# Install via ADB
adb install -r app/build/outputs/apk/debug/rle-mobile-debug.apk
```

## Manual Build Steps

1. Open Android Studio
2. File → Open → Select `lab/android` folder
3. Wait for Gradle sync to complete
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK location: `app/build/outputs/apk/debug/app-debug.apk`

## Installing on Device

### Via ADB (Sideload)

```bash
# Enable Developer Options on your phone:
# Settings → About Phone → Tap "Build Number" 7 times

# Enable USB Debugging:
# Settings → Developer Options → USB Debugging

# Connect phone via USB

# Check device is detected
adb devices

# Install APK
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Direct Transfer

1. Transfer `app-debug.apk` to phone via USB/Email
2. Enable "Install from Unknown Sources" in Settings
3. Tap APK file to install

## Troubleshooting

**"SDK not found"**
- File → Project Structure → SDK Location → Select Android SDK path

**"Gradle sync failed"**
- File → Invalidate Caches → Restart
- Or: `./gradlew clean` then rebuild

**"Build failed: minSdk 28 required"**
- This is intentional - app targets Android 9.0+
- Use Android 9.0+ device or emulator

**"Permission denied: /proc/stat"**
- This is normal - app uses `BatteryManager` instead
- Limited data vs desktop, but sufficient for RLE

## Expected File Size

- Debug APK: ~15-20 MB
- Release APK: ~8-12 MB (with R8)

## Next Steps

After installing:

1. Open "RLE Monitor" app
2. Tap "Start" to begin monitoring
3. Run your stress test or workload
4. Tap "Stop" when done
5. Tap "Export" to share CSV data
6. Import CSV into desktop analysis pipeline

## Verifying Installation

Check app can read sensors:

```bash
# Connect to device shell
adb shell

# Check app's telemetry access (should work without root)
ls -l /proc/stat                          # CPU data
ls -l /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq  # CPU freq
```

If these work, app will function properly.

## Deployment Notes

- **No Play Store**: This is a developer build, not published
- **Permissions**: App requires `FOREGROUND_SERVICE` and `WAKE_LOCK`
- **Safety**: App respects Android thermal throttling automatically
- **Data**: CSVs stored in `/data/data/com.rle.mobile/files/sessions/`

## Building Release APK (Optional)

```bash
# Create release keystore
keytool -genkey -v -keystore rle-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias rle

# Add to app/build.gradle.kts:
# signingConfigs {
#     create("release") {
#         storeFile = file("../rle-release.jks")
#         storePassword = "..."
#         keyAlias = "rle"
#         keyPassword = "..."
#     }
# }

# Build release
./gradlew assembleRelease

# APK location: app/build/outputs/apk/release/app-release.apk
```

## Testing on Emulator

Android Studio includes device emulator:

1. Tools → Device Manager
2. Create Virtual Device
3. Select Pixel 7 or similar (API 34)
4. Launch emulator
5. Deploy app to emulator via Android Studio

**Note**: Emulator battery telemetry is simulated - numbers won't match real device.

## Comparing Across Devices

After collecting data on phone:

```bash
# Desktop computer
python lab/analysis/rle_comprehensive_timeline.py \
    lab/sessions/recent/rle_20251027_19_cpu.csv \
    lab/sessions/recent/rle_20251027_19_gpu.csv

# Mobile (sideload CSV from phone)
python lab/analysis/rle_comprehensive_timeline.py \
    phone_rle_20251027_19_mobile.csv

# Cross-domain analysis
python lab/analysis/cross_domain_rle.py \
    lab/sessions/recent/rle_20251027_19_cpu.csv \
    lab/sessions/recent/rle_20251027_19_gpu.csv \
    phone_rle_20251027_19_mobile.csv
```

Phone data becomes just another device in your dataset. Same RLE law, proven across platforms.

