# RLE Android App - Mobile Deployment

## Overview

This Android app brings the RLE (Recursive Load Efficiency) monitoring system to mobile devices, specifically targeting the Galaxy S24 (and similar devices) to prove RLE works across form factors.

## What This App Does

**Core Function**: Samples hardware telemetry at 1 Hz and computes RLE in real-time, just like the desktop version.

**Android Telemetry Mapping**:
- `η (utilization)` → CPU utilization % from `/proc/stat`
- `σ (stability)` → Inverse of rolling standard deviation of utilization
- `α (load factor)` → Estimated power draw / baseline gaming power
- `τ (sustainability)` → Time counter for thermal management

**Output**: CSV logs compatible with desktop `rle_comprehensive_timeline.py` pipeline.

## Architecture

```
android/
├── app/
│   ├── src/main/java/com/rle/mobile/
│   │   ├── MainActivity.kt        # Compose UI dashboard
│   │   ├── TelemetryService.kt    # Foreground service that samples
│   │   ├── TelemetrySampler.kt    # Reads CPU/battery/thermal sensors
│   │   ├── RLEEngine.kt           # RLE computation (adapted from Python)
│   │   └── CsvLogger.kt           # Writes session data to CSV
│   └── src/main/res/
│       └── AndroidManifest.xml   # Permissions (foreground service)
├── build.gradle.kts              # Gradle build config
└── README_ANDROID.md             # This file
```

## Key Differences from Desktop

1. **No GPU telemetry**: Phones don't expose GPU power without root
2. **Battery proxies for power**: Use battery current draw as α proxy
3. **Thermal throttling hints**: Use Android `ThermalStatusListener` for evidence
4. **Simplified collapse detection**: Same algorithm, tuned for phone thermal curves

## Safety Considerations

**READ THIS**:
- DO NOT run infinite 100% CPU for an hour without cooling
- Place phone on table (not hand/pocket) - skin is insulator
- Run 2-5 minute load tests first (20%, 50%, 80%), not instant max
- Phone thermal response is faster than desktop (lead time ≠ 700ms)

## Building & Deploying

```bash
# Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK API 34
- Kotlin 1.9+

# Build
./gradlew assembleDebug

# Install via ADB
adb install -r app/build/outputs/apk/debug/rle-mobile-debug.apk

# Start monitoring
# Open app, tap "Start Monitoring"

# Export data
# Tap "Export CSV" → Share via email/Drive
```

## Alternative: Physics Toolbox Sensor Suite

If you already own **Physics Toolbox Sensor Suite** (paid version), you can use it to export sensor data and convert to RLE format using the desktop converter:

```bash
# 1. Export sensor data from Physics Toolbox on your phone
# (File → Export → CSV)

# 2. Transfer CSV to desktop

# 3. Convert to RLE format
python lab/analysis/physics_toolbox_rle.py phone_sensors.csv phone_rle.csv

# 4. Analyze with existing pipeline
python lab/analysis/rle_comprehensive_timeline.py phone_rle.csv
```

**Advantages of Physics Toolbox**:
- More sensors (if supported by your device)
- Professional-grade data export
- Already on your phone

**Advantages of this Android app**:
- Computes RLE in real-time
- Shows live dashboard
- Automatic logging (no manual export)
- Built for RLE workflow

You can use either approach - both output the same RLE-compatible CSV format.

## Expected Behavior

**Normal Operation**:
- Samples at 1 Hz (configurable)
- Logs to app storage: `/Android/data/com.rle.mobile/files/sessions/`
- Shows live dashboard: RLE, battery temp, CPU utilization
- Safety alerts: Green (>0.5), Yellow (0.3-0.5), Red (≤0.3)

**Session Format** (CSV):
```
timestamp,device,rle_smoothed,rle_raw,rle_norm,E_th,E_pw,temp_c,power_w,util_pct,a_load,t_sustain_s,cycles_per_joule,alerts
2025-10-27T19:00:00Z,mobile,0.452300,0.450123,0.78,0.65,0.70,45.2,8.5,65.0,0.85,120.0,1.2e8,|
```

## Integration with Desktop Pipeline

The generated CSVs are **fully compatible** with existing analysis tools:

```bash
# Analyze phone session
python lab/analysis/rle_comprehensive_timeline.py \
    sessions/recent/rle_20251027_19_mobile.csv

# Compare across devices (phone as "device #3")
python lab/analysis/cross_domain_rle.py \
    sessions/recent/rle_20251027_19_cpu.csv \
    sessions/recent/rle_20251027_19_gpu.csv \
    sessions/recent/rle_20251027_19_mobile.csv
```

## Permissions Required

- `FOREGROUND_SERVICE` - For background monitoring
- `WAKE_LOCK` - Optional, to keep sampling while screen off
- `BATTERY_STATS` (informational) - Mostly gated, BatteryManager covers it

No dangerous permissions needed. No root required.

## Current Limitations

1. **No GPU telemetry**: Samsung locks GPU sensors (would need root)
2. **Power is estimated**: Battery current × voltage ≈ watts (not perfect)
3. **Thermal limits are guesses**: We don't know phone's Tmax (use 80°C as safe default)
4. **CPU frequency varies**: Big/little cluster mixing (we track big cluster as proxy)

These don't break RLE. They just make the numbers slightly less precise than desktop.

## Roadmap

- [x] Telemetry sampler (CPU, battery, thermal)
- [x] RLE computation engine
- [x] CSV logging
- [x] Compose UI dashboard
- [ ] Export/Share functionality
- [ ] Session duration tracking
- [ ] Autostop at thermal limit
- [ ] Side-by-side desktop comparison view

## Credits

Adapted from `lab/monitoring/hardware_monitor.py` for Android.

