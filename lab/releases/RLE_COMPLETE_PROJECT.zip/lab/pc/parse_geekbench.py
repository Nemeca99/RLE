#!/usr/bin/env python3
"""
Parse Geekbench files and extract performance data
"""

import json
import pandas as pd
from datetime import datetime, timedelta

# Read CPU benchmark
with open('Samsung Galaxy S24 Ultra CPU Benchmark - 2025-10-27 16_23_03.gb6', 'r') as f:
    cpu_data = json.load(f)

# Read GPU benchmark
with open('Samsung Galaxy S24 Ultra GPU Benchmark - 2025-10-27 16_25_37.gb6', 'r') as f:
    gpu_data = json.load(f)

print("=== CPU Benchmark (Geekbench 6) ===")
print(f"  Date: {cpu_data['date']}")
print(f"  CPU: {cpu_data['metrics'][8]['value']}")  # Qualcomm Snapdragon 8 Gen 3
print(f"  Single-Core Score: {cpu_data['score']}")
print(f"  Multi-Core Score: {cpu_data['multicore_score']}")
print(f"  Runtime: {cpu_data['runtime']:.1f} seconds")
print(f"  Clock: {cpu_data['clock']:.2f} GHz")

print("\n=== GPU Benchmark (Geekbench 6) ===")
print(f"  Date: {gpu_data['date']}")
print(f"  GPU: {gpu_data['metrics'][34]['value']}")  # Adreno (TM) 750
print(f"  Vulkan Score: {gpu_data['score']}")
print(f"  Runtime: {gpu_data['runtime']:.1f} seconds")
print(f"  Clock: {gpu_data['clock']:.2f} GHz")

print("\n=== CPU Workloads ===")
for workload in cpu_data['sections'][0]['workloads']:
    print(f"  {workload['name']}: score={workload['score']}, runtime={workload['runtime']:.3f}s")

print("\n=== GPU Workloads ===")
for workload in gpu_data['sections'][0]['workloads']:
    print(f"  {workload['name']}: score={workload['score']}, runtime={workload['runtime']:.3f}s")

# Extract performance data from CPU benchmark
cpu_samples = []
for section in cpu_data['sections']:
    for workload in section['workloads']:
        # Each workload has runtime data
        for i, rt in enumerate(workload['runtimes']):
            cpu_samples.append({
                'workload': workload['name'],
                'runtime': rt,
                'score': workload['score'],
                'type': 'cpu'
            })

print(f"\nExtracted {len(cpu_samples)} CPU runtime samples")
print(f"CPU runtime range: {min(c['runtime'] for c in cpu_samples):.3f}s - {max(c['runtime'] for c in cpu_samples):.3f}s")

# Extract GPU data
gpu_samples = []
for section in gpu_data['sections']:
    for workload in section['workloads']:
        for i, rt in enumerate(workload['runtimes']):
            gpu_samples.append({
                'workload': workload['name'],
                'runtime': rt,
                'score': workload['score'],
                'type': 'gpu'
            })

print(f"Extracted {len(gpu_samples)} GPU runtime samples")
print(f"GPU runtime range: {min(c['runtime'] for c in gpu_samples):.3f}s - {max(c['runtime'] for c in gpu_samples):.3f}s")

print("\nNOTE: Geekbench doesn't record temperature, so we can't compute RLE directly.")
print("These benchmarks provide performance baseline data to compare with 3DMark.")
print("\nSummary:")
print(f"  CPU baseline: {cpu_data['score']} single-core, {cpu_data['multicore_score']} multi-core")
print(f"  GPU baseline: {gpu_data['score']} Vulkan score")

