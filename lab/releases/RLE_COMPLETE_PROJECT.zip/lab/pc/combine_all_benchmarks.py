#!/usr/bin/env python3
"""
Combine Geekbench CPU/GPU + 3DMark thermal data
Extrapolate temperature based on workload intensity
"""

import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Read Geekbench files
with open('Samsung Galaxy S24 Ultra CPU Benchmark - 2025-10-27 16_23_03.gb6', 'r') as f:
    cpu_bench = json.load(f)

with open('Samsung Galaxy S24 Ultra GPU Benchmark - 2025-10-27 16_25_37.gb6', 'r') as f:
    gpu_bench = json.load(f)

# Read existing 3DMark data
wildlife_df = pd.read_csv('phone_rle_wildlife.csv')

print("=== Combining All Benchmark Data ===")
print(f"3DMark: {len(wildlife_df)} samples")
print(f"Geekbench CPU: {len(cpu_bench['sections'][0]['workloads'])} workloads")
print(f"Geekbench GPU: {len(gpu_bench['sections'][0]['workloads'])} workloads")

# Estimate temperature for Geekbench based on workload intensity
# Higher score/workload = more heat
def estimate_temp_from_workload(score, baseline_temp=33):
    """Estimate temp based on workload score"""
    # Normalize score (Geekbench 6 typical scores: 1000-25000)
    # More realistic thermal model
    if score < 5000:
        # Light load: 33-38°C
        return baseline_temp + (score / 5000 * 5)
    else:
        # Heavy load: 38-45°C
        return 38 + ((score - 5000) / 20000 * 7)

# Extract CPU workload timeline
cpu_samples = []
start_time = datetime(2025, 10, 27, 16, 23, 0)  # Geekbench start time
current_time = start_time

for section in cpu_bench['sections']:
    for workload in section['workloads']:
        # Each workload has multiple iterations
        for i, rt in enumerate(workload['runtimes']):
            current_time += timedelta(seconds=rt)
            # Estimate temperature based on workload intensity
            # CPU starts warmer after 3DMark stress
            est_temp = estimate_temp_from_workload(workload['score'], baseline_temp=40)
            
            cpu_samples.append({
                'timestamp': current_time.isoformat() + 'Z',
                'device': 'mobile',
                'benchmark': 'geekbench_cpu',
                'workload': workload['name'],
                'runtime': rt,
                'score': workload['score'],
                'estimated_temp_c': est_temp,
            })

# Extract GPU workload timeline
gpu_samples = []
start_time = datetime(2025, 10, 27, 16, 25, 0)  # GPU benchmark start
current_time = start_time

for section in gpu_bench['sections']:
    for workload in section['workloads']:
        for i, rt in enumerate(workload['runtimes']):
            current_time += timedelta(seconds=rt)
            # GPU starts slightly cooler (brief cooldown between benchmarks)
            est_temp = estimate_temp_from_workload(workload['score'], baseline_temp=37)
            
            gpu_samples.append({
                'timestamp': current_time.isoformat() + 'Z',
                'device': 'mobile',
                'benchmark': 'geekbench_gpu',
                'workload': workload['name'],
                'runtime': rt,
                'score': workload['score'],
                'estimated_temp_c': est_temp,
            })

# Combine all data
geekbench_df = pd.DataFrame(cpu_samples + gpu_samples)

print(f"\nCreated {len(geekbench_df)} Geekbench samples")
print(f"  Temp range (estimated): {geekbench_df['estimated_temp_c'].min():.1f}°C - {geekbench_df['estimated_temp_c'].max():.1f}°C")

# Merge with 3DMark data
# First ensure consistent timestamp format
wildlife_df['timestamp'] = pd.to_datetime(wildlife_df['timestamp'])
geekbench_df['timestamp'] = pd.to_datetime(geekbench_df['timestamp'])

combined_df = pd.concat([
    wildlife_df,
    geekbench_df
], ignore_index=True)

# Sort by timestamp
combined_df = combined_df.sort_values('timestamp').reset_index(drop=True)

print(f"\nCombined dataset: {len(combined_df)} total samples")
print(f"  Time span: {combined_df['timestamp'].min()} to {combined_df['timestamp'].max()}")

# Save combined data
combined_df.to_csv('phone_all_benchmarks.csv', index=False)
print("\nSaved to phone_all_benchmarks.csv")

# Summary
print("\n=== Benchmark Summary ===")
print(f"3DMark (Wild Life Extreme):")
print(f"  Samples: {len(wildlife_df)}")
print(f"  Temp: 33°C → 44°C")
print(f"  RLE: 0.131 - 0.489")

print(f"\nGeekbench (CPU + GPU):")
print(f"  Samples: {len(geekbench_df)}")
print(f"  CPU Score: {cpu_bench['multicore_score']}")
print(f"  GPU Score: {gpu_bench['score']}")
print(f"  Est. Temp: {geekbench_df['estimated_temp_c'].min():.1f}°C - {geekbench_df['estimated_temp_c'].max():.1f}°C")

print(f"\nCombined: Complete thermal profile from idle → light load → heavy stress")

