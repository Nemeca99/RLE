import pandas as pd
df = pd.read_csv('phone_rle_final.csv')
print(f"Total samples: {len(df)}")
print(f"Temp range: {df['temp_c'].min():.1f}°C - {df['temp_c'].max():.1f}°C") 
print(f"RLE range: {df['rle_smoothed'].dropna().min():.3f} - {df['rle_smoothed'].dropna().max():.3f}")
print(f"Collapse rate: {df['collapse'].sum()}/{len(df)} ({100*df['collapse'].sum()/len(df):.1f}%)")
print(f"Duration: {len(df)/60:.1f} minutes")

