#!/usr/bin/env python3
"""
Extract telemetry data from Perfetto trace
"""

from perfetto.trace_processor import TraceProcessor
import pandas as pd
import os
import sys

trace_file = 'stack-samples-pineapple-BP2A.250605.031.A3-2025-10-27-16-34-30.perfetto-trace'

print(f"Opening Perfetto trace: {trace_file}")

# Try to find trace processor executable
# On Windows, it might be in PATH or need to be downloaded
# For now, let's try the simple approach
try:
    tp = TraceProcessor(trace_file)
except Exception as e:
    print(f"Error opening trace: {e}")
    print("\nPerfetto trace processor may need to be installed separately.")
    print("The trace file contains high-resolution telemetry data, but requires")
    print("the trace_processor_shell executable to parse.")
    print("\nAlternative: Upload trace to https://ui.perfetto.dev and export CSV")
    sys.exit(0)

print("Connected to trace processor")

# Query available tables
tables = tp.tables()
print(f"Available tables: {list(tables)}")

# Query CPU frequency data
print("\n=== Extracting CPU Data ===")
try:
    cpu_freq_query = "SELECT ts, cpu, freq FROM cpu_freq WHERE freq IS NOT NULL"
    cpu_freq = tp.query(cpu_freq_query)
    df_cpu_freq = pd.DataFrame(cpu_freq)
    print(f"CPU frequency samples: {len(df_cpu_freq)}")
    if len(df_cpu_freq) > 0:
        print(df_cpu_freq.head())
except Exception as e:
    print(f"Error querying CPU freq: {e}")

# Query process data
print("\n=== Extracting Process Data ===")
try:
    process_query = "SELECT ts, pid, name FROM process WHERE name IS NOT NULL LIMIT 100"
    process = tp.query(process_query)
    df_process = pd.DataFrame(process)
    print(f"Process samples: {len(df_process)}")
    if len(df_process) > 0:
        print(df_process.head())
except Exception as e:
    print(f"Error querying process: {e}")

# Query thermal data (if available)
print("\n=== Extracting Thermal Data ===")
try:
    thermal_query = "SELECT ts, name, temperature FROM thermal WHERE temperature IS NOT NULL"
    thermal = tp.query(thermal_query)
    df_thermal = pd.DataFrame(thermal)
    print(f"Thermal samples: {len(df_thermal)}")
    if len(df_thermal) > 0:
        print(df_thermal.head())
except Exception as e:
    print(f"Error querying thermal: {e}")

# Query battery data
print("\n=== Extracting Battery Data ===")
try:
    battery_query = "SELECT ts, charge_uah FROM battery WHERE charge_uah IS NOT NULL"
    battery = tp.query(battery_query)
    df_battery = pd.DataFrame(battery)
    print(f"Battery samples: {len(df_battery)}")
    if len(df_battery) > 0:
        print(df_battery.head())
except Exception as e:
    print(f"Error querying battery: {e}")

# Query power data
print("\n=== Extracting Power Data ===")
try:
    power_query = "SELECT ts, value FROM power WHERE value IS NOT NULL"
    power = tp.query(power_query)
    df_power = pd.DataFrame(power)
    print(f"Power samples: {len(df_power)}")
    if len(df_power) > 0:
        print(df_power.head())
except Exception as e:
    print(f"Error querying power: {e}")

print("\n=== Summary ===")
print("Perfetto trace contains high-resolution system telemetry.")
print("This is REAL data from your phone's kernel, not estimates.")
print("\nTo convert to RLE format:")
print("  1. Extract time series of CPU freq, temp, power")
print("  2. Sample at 1 Hz resolution")
print("  3. Convert to RLE using mobile_to_rle.py")

tp.close()

