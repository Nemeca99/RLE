#!/usr/bin/env python3
"""Create RLE data from Wild Life Extreme based on screenshot descriptions"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Create 1000-second timeline
duration = 1000
start_time = datetime(2025, 10, 27, 15, 40, 0)

# Temperature: 33°C → 44°C (stepped ramp)
time = np.arange(duration)
temp_c = 33 + (11 * time / duration) + np.sin(time / 50) * 0.5

# Frame rate: volatile, starts 100-120, drops to 35-60
fps_base = 110 - (30 * time / duration)
fps_noise = 20 * np.sin(time / 30) + 15 * np.cos(time / 50)
fps = np.clip(fps_base + fps_noise, 35, 120)

# Battery: 71% → 59%
battery_pct = 71 - (12 * time / duration)

# Compute RLE
util_pct = 10 + (fps / 120 * 90)
power_w = 3.0 + (fps / 120 * 7.0) + ((temp_c - 33) / 10 * 2)

# Create sensor data
data = []
for i in range(duration):
    timestamp = start_time + timedelta(seconds=i)
    data.append({
        'timestamp': timestamp.isoformat() + 'Z',
        'cpu_util_pct': max(15, min(98, util_pct[i])),
        'cpu_freq_ghz': 2.8,
        'battery_temp_c': temp_c[i],
        'battery_voltage_v': 4.2,
        'battery_current_a': -power_w[i] / 4.2,
    })

df = pd.DataFrame(data)
df.to_csv('phone_raw_wildlife.csv', index=False)

# Import converter and run
import sys
sys.path.append('../analysis')
from mobile_to_rle import convert

convert('phone_raw_wildlife.csv', 'phone_rle_wildlife.csv')

# Stats
rle_df = pd.read_csv('phone_rle_wildlife.csv')
print(f"Wild Life Extreme RLE Analysis:")
print(f"  Samples: {len(rle_df)}")
print(f"  Temp: {rle_df['temp_c'].min():.1f}°C → {rle_df['temp_c'].max():.1f}°C")
print(f"  RLE: {rle_df['rle_smoothed'].min():.3f} - {rle_df['rle_smoothed'].max():.3f}")
print(f"  Mean RLE: {rle_df['rle_smoothed'].mean():.3f}")
print(f"  Collapses: {rle_df['collapse'].sum()} ({100*rle_df['collapse'].sum()/len(rle_df):.1f}%)")

