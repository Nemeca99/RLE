package com.rle.mobile

import android.app.ServiceConnection
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.rle.mobile.ui.theme.RLETheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Main Activity - Compose UI Dashboard
 * 
 * Displays live RLE metrics, battery temp, CPU utilization, and status.
 * Same principles as desktop Streamlit dashboard.
 */
class MainActivity : ComponentActivity() {
    
    private var service: TelemetryService? = null
    private var isBound = false
    
    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val binder = binder as TelemetryService.LocalBinder
            service = binder.getService()
            isBound = true
        }
        
        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            isBound = false
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            RLETheme {
                val isMonitoring = remember { mutableStateOf(false) }
                val latestSample = remember { mutableStateOf<TelemetrySampler.Sample?>(null) }
                val latestRLE = remember { mutableStateOf<RLEEngine.RLEResult?>(null) }
                
                // Update UI every second
                LaunchedEffect(Unit) {
                    while (true) {
                        delay(1000)
                        if (isBound && service != null) {
                            latestSample.value = service?.latestSample
                            latestRLE.value = service?.latestRLE
                        }
                    }
                }
                
                // Start/Stop button handler
                val onStartStop = {
                    if (isMonitoring.value) {
                        stopMonitoring()
                        isMonitoring.value = false
                    } else {
                        startMonitoring()
                        isMonitoring.value = true
                    }
                }
                
                Dashboard(
                    isMonitoring = isMonitoring.value,
                    latestSample = latestSample.value,
                    latestRLE = latestRLE.value,
                    onStartStop = onStartStop,
                    onExport = { exportData() }
                )
            }
        }
    }
    
    override fun onStart() {
        super.onStart()
        val intent = Intent(this, TelemetryService::class.java)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }
    
    override fun onStop() {
        super.onStop()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
    
    private fun startMonitoring() {
        val intent = Intent(this, TelemetryService::class.java).apply {
            action = TelemetryService.ACTION_START
        }
        startForegroundService(intent)
        Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show()
    }
    
    private fun stopMonitoring() {
        val intent = Intent(this, TelemetryService::class.java).apply {
            action = TelemetryService.ACTION_STOP
        }
        startForegroundService(intent)
        Toast.makeText(this, "Monitoring stopped", Toast.LENGTH_SHORT).show()
    }
    
    private fun exportData() {
        // TODO: Implement CSV export via Share sheet
        Toast.makeText(this, "Export feature coming soon", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun Dashboard(
    isMonitoring: Boolean,
    latestSample: TelemetrySampler.Sample?,
    latestRLE: RLEEngine.RLEResult?,
    onStartStop: () -> Unit,
    onExport: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Text(
            text = "RLE Mobile Monitor",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        
        // Status indicator
        val statusColor = when {
            latestRLE?.rleSmoothed == null -> MaterialTheme.colorScheme.primary
            latestRLE.rleSmoothed > 0.5 -> androidx.compose.ui.graphics.Color(0xFF4CAF50)  // Green
            latestRLE.rleSmoothed > 0.3 -> androidx.compose.ui.graphics.Color(0xFFFFC107)  // Yellow
            else -> androidx.compose.ui.graphics.Color(0xFFF44336)  // Red
        }
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = statusColor.copy(alpha = 0.1f)
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "RLE Status",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = latestRLE?.rleSmoothed?.let { 
                        String.format("%.4f", it)
                    } ?: "N/A",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    text = when {
                        latestRLE?.rleSmoothed == null -> "No data"
                        latestRLE.rleSmoothed > 0.5 -> "✓ Optimal"
                        latestRLE.rleSmoothed > 0.3 -> "⚠ Warning"
                        else -> "✗ Critical"
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        
        // Metrics grid
        if (latestSample != null) {
            MetricGrid(sample = latestSample, rle = latestRLE)
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onStartStop,
                modifier = Modifier.weight(1f)
            ) {
                Text(if (isMonitoring) "Stop" else "Start")
            }
            
            Button(
                onClick = onExport,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Text("Export")
            }
        }
    }
}

@Composable
fun MetricGrid(sample: TelemetrySampler.Sample, rle: RLEEngine.RLEResult?) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Live Metrics",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        
        MetricCard("CPU Utilization", "${String.format("%.1f", sample.cpuUtilPct)}%")
        MetricCard("CPU Frequency", "${String.format("%.2f", sample.cpuFreqHz / 1e9)} GHz")
        MetricCard("Battery Temp", "${sample.batteryTempC?.let { String.format("%.1f", it) } ?: "N/A"}°C")
        
        rle?.let {
            MetricCard("Power Efficiency (E_pw)", String.format("%.4f", it.ePw))
            MetricCard("Thermal Efficiency (E_th)", String.format("%.4f", it.eTh))
            MetricCard("Load Factor (α)", String.format("%.3f", it.aLoad))
            MetricCard("Sustainability (τ)", String.format("%.1f", it.tSustain))
        }
    }
}

@Composable
fun MetricCard(label: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

