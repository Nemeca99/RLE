package com.rle.mobile

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Foreground Service for RLE Monitoring
 * 
 * Runs at 1 Hz, samples telemetry, computes RLE, logs to CSV.
 * Same behavior as hardware_monitor.py, but for Android.
 */
class TelemetryService : Service() {
    
    private val binder = LocalBinder()
    private val executor = Executors.newSingleThreadExecutor()
    private var isMonitoring = false
    
    private lateinit var sampler: TelemetrySampler
    private lateinit var rleEngine: RLEEngine
    private lateinit var logger: CsvLogger
    private var wakelock: PowerManager.WakeLock? = null
    
    // Live data for UI
    var latestSample: TelemetrySampler.Sample? = null
    var latestRLE: RLEEngine.RLEResult? = null
    
    inner class LocalBinder : Binder() {
        fun getService(): TelemetryService = this@TelemetryService
    }
    
    override fun onCreate() {
        super.onCreate()
        
        sampler = TelemetrySampler(this)
        rleEngine = RLEEngine(
            tempLimitC = 80.0,
            baselineGamingPowerW = 8.0
        )
        logger = CsvLogger(this)
        
        // Acquire wake lock to keep sampling during screen off
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakelock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RLE::MonitorWakelock")
        
        startForeground(NOTIFICATION_ID, createNotification())
    }
    
    override fun onBind(intent: Intent?): IBinder = binder
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startMonitoring()
            ACTION_STOP -> stopMonitoring()
        }
        return START_STICKY
    }
    
    private fun startMonitoring() {
        if (isMonitoring) return
        
        isMonitoring = true
        wakelock?.acquire(10*60*60*1000L)  // 10 hours max
        
        executor.submit {
            monitorLoop()
        }
        
        updateNotification("Monitoring active...")
    }
    
    private fun stopMonitoring() {
        isMonitoring = false
        wakelock?.release()
        
        logger.close()
        
        updateNotification("Monitoring stopped")
    }
    
    /**
     * Main monitoring loop (1 Hz)
     */
    private fun monitorLoop() {
        val tickMillis = 1000L
        
        while (isMonitoring) {
            val loopStart = System.currentTimeMillis()
            
            // Sample telemetry
            val sample = sampler.sample()
            latestSample = sample
            
            // Compute RLE
            val timestamp = System.currentTimeMillis()
            val tempC = sample.batteryTempC
            val powerW = sample.estimatePowerW()
            val rleResult = rleEngine.compute(
                timestamp = timestamp,
                utilPct = sample.cpuUtilPct,
                tempC = tempC,
                powerW = powerW,
                thermalStatus = sample.thermalStatus
            )
            latestRLE = rleResult
            
            // Log to CSV
            val isoTime = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
                    .apply { timeZone = TimeZone.getTimeZone("UTC") }
                    .format(Date())
            
            logger.log(isoTime, rleResult, sample)
            
            // Sleep until next tick
            val elapsed = System.currentTimeMillis() - loopStart
            val sleepTime = tickMillis - elapsed
            if (sleepTime > 0) {
                Thread.sleep(sleepTime)
            } else {
                // Fell behind schedule
                Thread.yield()
            }
        }
    }
    
    private fun createNotification(): Notification {
        val channelId = "rle_monitor_channel"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "RLE Monitoring",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background RLE telemetry collection"
            }
            
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("RLE Monitor")
            .setContentText("Monitoring active...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }
    
    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(
            NOTIFICATION_ID,
            createNotification().apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    setContentText(text)
                }
            }
        )
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopMonitoring()
    }
    
    companion object {
        const val ACTION_START = "com.rle.mobile.START"
        const val ACTION_STOP = "com.rle.mobile.STOP"
        private const val NOTIFICATION_ID = 1001
    }
}

