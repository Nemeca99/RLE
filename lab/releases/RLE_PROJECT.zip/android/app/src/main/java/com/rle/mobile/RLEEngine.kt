package com.rle.mobile

import kotlin.math.max
import kotlin.math.min

/**
 * RLE Computation Engine - Adapted from hardware_monitor.py
 * 
 * Computes Recursive Load Efficiency metric from utilization, temperature, power data.
 * This is the core physics - same law as desktop, adapted for mobile sensors.
 */
class RLEEngine(
    private val tempLimitC: Double = 80.0,  // Mobile SoC thermal limit
    private val baselineGamingPowerW: Double = 8.0,  // S24 typical sustained gaming power
    private val maxTSustain: Double = 600.0
) {
    
    data class RLEResult(
        val rleRaw: Double,
        val rleSmoothed: Double,
        val rleNorm: Double,
        val eTh: Double,  // Thermal efficiency component
        val ePw: Double,  // Power efficiency component
        val tSustain: Double,
        val utilPct: Double,
        val stability: Double,
        val aLoad: Double
    )
    
    /**
     * Rolling buffer for time-series data
     */
    class RollingBuffer<T>(private val capacity: Int) {
        private val buffer = mutableListOf<T>()
        
        fun add(value: T) {
            buffer.add(value)
            if (buffer.size > capacity) {
                buffer.removeAt(0)
            }
        }
        
        fun last(n: Int = 1): List<T> {
            val size = buffer.size
            if (size == 0) return emptyList()
            val k = min(n, size)
            return buffer.subList(size - k, size)
        }
        
        fun values(): List<T> = buffer.toList()
        fun size(): Int = buffer.size
        fun mean(): Double? = if (buffer.isEmpty()) null else {
            if (buffer[0] is Number) {
                buffer.map { (it as Number).toDouble() }.average()
            } else null
        }
        
        fun stdev(): Double {
            if (buffer.size < 2) return 0.0
            val values = buffer.map { (it as Number).toDouble() }
            val mean = values.average()
            val variance = values.map { (it - mean) * (it - mean) }.average()
            return kotlin.math.sqrt(variance)
        }
    }
    
    // State
    private val utilHist = RollingBuffer<Double>(120)
    private val tempHist = RollingBuffer<Double>(120)
    private val rleHist = RollingBuffer<Double>(5)  // Smoothing window
    private var rollingPeak = 0.0
    private var belowCounter = 0
    
    private var warmup = false
    private var warmupEnd = 0L
    private val warmupSec = 60
    
    /**
     * Add a sample and compute RLE
     */
    fun compute(
        timestamp: Long,
        utilPct: Double,
        tempC: Double?,
        powerW: Double?,
        thermalStatus: Int  // 0=NORMAL, 1=LIGHT, 2=MODERATE, 3=SEVERE, 4=CRITICAL
    ): RLEResult? {
        
        // Check warmup
        if (!warmup) {
            warmupEnd = timestamp
            warmup = true
        }
        val isWarm = (timestamp - warmupEnd) > warmupSec * 1000
        
        // Store history
        utilHist.add(utilPct)
        tempHist.add(tempC ?: 45.0)  // Default if no temp
        
        // Ensure we have enough history
        if (utilHist.size() < 5) {
            return null
        }
        
        // Map power to α (load factor)
        val aLoad = if (powerW != null && powerW > 0) {
            powerW / baselineGamingPowerW
        } else {
            // Fallback: estimate from utilization
            utilPct / 100.0 * 1.2  // Assume 120% max utilization ≈ 1.2 load
        }
        
        // Compute RLE components
        val util = utilPct / 100.0
        val stability = computeStability()
        val tSustain = computeTSustain(tempLimitC, tempC ?: 45.0)
        
        // Compute RLE
        val denominator = max(aLoad, 1e-3) * (1.0 + 1.0 / tSustain)
        val rleRaw = (util * stability) / denominator
        
        // Split efficiency components
        val eTh = stability / (1.0 + 1.0 / tSustain)
        val ePw = util / max(aLoad, 1e-3)
        
        // Smooth RLE
        rleHist.add(rleRaw)
        val rleSmoothed = rleHist.mean() ?: rleRaw
        
        // Normalize to 0-1 range
        val rleNorm = normalizeRLE(rleSmoothed, utilPct)
        
        // Collapse detection (only after warmup)
        if (isWarm) {
            // Rolling peak with decay (0.998 per tick = 3% drop per 10s)
            rollingPeak = max(rleSmoothed, rollingPeak * 0.998)
            
            // Smart gate: require real load AND heating
            val underLoad = (utilPct > 60) || (aLoad > 0.75)
            val heating = tempHist.size() >= 2 && 
                         (tempHist.values()[tempHist.size() - 1] - tempHist.values()[tempHist.size() - 2] > 0.05)
            val gate = underLoad && heating
            
            // Hysteresis: 7-second drop below 65% of peak
            val drop = rleSmoothed < 0.65 * rollingPeak
            if (gate && drop) {
                belowCounter++
            } else {
                belowCounter = 0
            }
        }
        
        return RLEResult(
            rleRaw = rleRaw,
            rleSmoothed = rleSmoothed,
            rleNorm = rleNorm,
            eTh = eTh,
            ePw = ePw,
            tSustain = tSustain,
            utilPct = utilPct,
            stability = stability,
            aLoad = aLoad
        )
    }
    
    /**
     * Compute stability (inverse of jitter)
     * σ = 1 / (1 + stddev)
     */
    private fun computeStability(): Double {
        if (utilHist.size() < 5) return 1.0
        val jitter = utilHist.stdev()
        return 1.0 / (1.0 + jitter)
    }
    
    /**
     * Compute sustainability time constant
     * τ = (T_limit - T_current) / (dT/dt)
     */
    private fun computeTSustain(tempLimit: Double, currentTemp: Double): Double {
        if (tempHist.size() < 2) return maxTSustain
        
        val temps = tempHist.values()
        val dT = temps.last() - temps[temps.size - 2]
        
        // dT/dt (assuming 1 Hz sampling)
        val dTdt = max(dT / 1.0, 1e-3)
        
        // Time until thermal limit
        val tSustain = (tempLimit - currentTemp) / dTdt
        
        return max(min(tSustain, maxTSustain), 1.0)
    }
    
    /**
     * Normalize RLE to 0-1 range
     * 1.0 = optimal, 0.0 = baseline
     */
    private fun normalizeRLE(rle: Double, utilPct: Double): Double {
        val baseline = 0.2   // RLE at minimal load
        val optimal = 4.0    // Peak RLE at sweet spot (40% load)
        val peakLoad = 60.0  // Load where RLE peaks
        
        // Expected RLE for this utilization
        val expectedRLE = if (utilPct <= peakLoad) {
            baseline + (optimal - baseline) * (utilPct / peakLoad)
        } else {
            optimal - (optimal - baseline * 0.5) * ((utilPct - peakLoad) / (100 - peakLoad))
        }
        
        return min(1.0, max(0.0, rle / expectedRLE))
    }
    
    /**
     * Check if system is in collapse state
     */
    fun isCollapsed(): Boolean {
        return belowCounter >= 7
    }
    
    /**
     * Get rolling peak value
     */
    fun getRollingPeak(): Double = rollingPeak
    
    /**
     * Get cycle counter
     */
    fun getCyclesPerJoule(freqHz: Double, powerW: Double?): Double? {
        if (powerW == null || powerW <= 0) return null
        val freqGHz = freqHz / 1e9
        val cyclesPerSec = freqGHz * 1e9  // cycles/sec
        val joulesPerSec = powerW  // watts = joules/sec
        return cyclesPerSec / joulesPerSec  // cycles/joule
    }
}

